# GTA VI Android mock-up

This is a small Android app project for a GTA VI-inspired visual mock-up. It is not the GTA VI game and does not contain gameplay or official Rockstar assets.

## Build the APK online (phone-friendly)

1. Sign in to GitHub and create a **new public repository** named `GTA-VI-Android`.
2. Upload the contents of this ZIP to the repository. Make sure `.github/workflows/build.yml` is included.
3. Open the repository's **Actions** tab.
4. Select **Build GTA VI APK** and tap **Run workflow** (or push to `main`).
5. When the run finishes, open it and download the **GTA-VI-Android** artifact.
6. Extract the artifact ZIP to get `app-debug.apk`, then install it on your Android phone.

The generated debug APK is for testing. Android may ask you to allow installation from your browser or file manager.
